
package rpgamev001;
public class Weapon extends Item{
    
}
