
package rpgamev001;
public class GameMechanics {
    //savings & loading
    //newplayer
    //create random opponent
    //mechanics of battle and arena
    //shopping mechanics
    //jobs mechanics (mby in another class who know)
    
}
