
package rpgamev001;
public class Opponent extends Person{
    
}
