
package rpgamev001;
public class Appv001 {

    public static void main(String[] args) {
        
    }
}
