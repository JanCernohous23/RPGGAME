
package rpgamev001;
public class Item {
    private String nameOfWeapon;
    private float power;
    private float durability;
    private StateOfItem stateofitem;
}
