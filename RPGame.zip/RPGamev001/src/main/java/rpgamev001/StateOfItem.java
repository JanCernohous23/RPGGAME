
package rpgamev001;
public enum StateOfItem {
    
}
