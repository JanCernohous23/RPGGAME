
package rpgamev001;
public class Armor extends Item{
    
}
