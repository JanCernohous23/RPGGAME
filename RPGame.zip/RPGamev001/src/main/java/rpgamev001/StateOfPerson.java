
package rpgamev001;
public enum StateOfPerson {
    
}
