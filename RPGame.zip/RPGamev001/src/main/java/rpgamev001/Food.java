
package rpgamev001;
public class Food extends Item{
    
}
