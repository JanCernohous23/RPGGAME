
package rpgamev001;
public class Person {
    private String name;
    private String job;
    private float hp;
    private int level;
    private int age;
    private float speed;
    private float strength;
    private float intelligence;
    private StateOfPerson stateofperson;
}
