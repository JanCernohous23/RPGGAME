
package rpgamev001;
public class Player extends Person {
    private float sellability;
}
